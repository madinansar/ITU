// DO NOT MODIFY eval_game_state FUNCTION
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "connect4.h"
#include "game_bot.h"


void eval_game_state(GameState *gs)
{
    GameStatus status = get_game_status(gs);
    if (status == PLAYER_1_WIN)
    {
        gs->evaluation = 1000;
        return;
    }
    else if (status == PLAYER_2_WIN)
    {
        gs->evaluation = -1000;
        return;
    }
    else if (status == DRAW)
    {
        gs->evaluation = 0;
        return;
    }

    // Count the number of 3s in a row
    int player_1_3 = 0;
    int player_2_3 = 0;

    // Count the number of 2s in a row with an extra space around
    int player_1_2 = 0;
    int player_2_2 = 0;

    // Check horizontal
    for (int i = 0; i < gs->height; i++)
    {
        for (int j = 0; j <= gs->width - 3; j++)
        {
            int index = i * gs->width + j;

            int x_count = (gs->board[index] == 'X') + (gs->board[index + 1] == 'X') + (gs->board[index + 2] == 'X');
            int o_count = (gs->board[index] == 'O') + (gs->board[index + 1] == 'O') + (gs->board[index + 2] == 'O');
            int empty_count = (gs->board[index] == '_') + (gs->board[index + 1] == '_') + (gs->board[index + 2] == '_');

            if (x_count == 3)
                player_1_3++;
            else if (o_count == 3)
                player_2_3++;
            else if (x_count == 2 && empty_count == 1)
                player_1_2++;
            else if (o_count == 2 && empty_count == 1)
                player_2_2++;
        }
    }

    // Check vertical
    for (int i = 0; i <= gs->height - 3; i++)
    {
        for (int j = 0; j < gs->width; j++)
        {
            int index = i * gs->width + j;
            // if (gs->board[index] != '_' &&
            //     gs->board[index] == gs->board[index + gs->width] &&
            //     gs->board[index] == gs->board[index + 2 * gs->width])
            // {
            //     if (gs->board[index] == 'X')
            //         player_1_3++;
            //     else
            //         player_2_3++;
            // }

            int x_count = (gs->board[index] == 'X') + (gs->board[index + gs->width] == 'X') + (gs->board[index + 2 * gs->width] == 'X');
            int o_count = (gs->board[index] == 'O') + (gs->board[index + gs->width] == 'O') + (gs->board[index + 2 * gs->width] == 'O');
            int empty_count = (gs->board[index] == '_') + (gs->board[index + gs->width] == '_') + (gs->board[index + 2 * gs->width] == '_');

            if (x_count == 3)
                player_1_3++;
            else if (o_count == 3)
                player_2_3++;
            else if (x_count == 2 && empty_count == 1)
                player_1_2++;
            else if (o_count == 2 && empty_count == 1)
                player_2_2++;
        }
    }

    // Check diagonal (top-left to bottom-right)
    for (int i = 0; i <= gs->height - 3; i++)
    {
        for (int j = 0; j <= gs->width - 3; j++)
        {
            int index = i * gs->width + j;
            // if (gs->board[index] != '_' &&
            //     gs->board[index] == gs->board[index + gs->width + 1] &&
            //     gs->board[index] == gs->board[index + 2 * gs->width + 2])
            // {
            //     if (gs->board[index] == 'X')
            //         player_1_3++;
            //     else
            //         player_2_3++;
            // }

            int x_count = (gs->board[index] == 'X') + (gs->board[index + gs->width + 1] == 'X') + (gs->board[index + 2 * gs->width + 2] == 'X');
            int o_count = (gs->board[index] == 'O') + (gs->board[index + gs->width + 1] == 'O') + (gs->board[index + 2 * gs->width + 2] == 'O');
            int empty_count = (gs->board[index] == '_') + (gs->board[index + gs->width + 1] == '_') + (gs->board[index + 2 * gs->width + 2] == '_');

            if (x_count == 3)
                player_1_3++;
            else if (o_count == 3)
                player_2_3++;
            else if (x_count == 2 && empty_count == 1)
                player_1_2++;
            else if (o_count == 2 && empty_count == 1)
                player_2_2++;
        }
    }

    // Check diagonal (top-right to bottom-left)
    for (int i = 0; i <= gs->height - 4; i++)
    {
        for (int j = gs->width - 1; j >= 2; j--)
        {
            int index = i * gs->width + j;
            // if (gs->board[index] != '_' &&
            //     gs->board[index] == gs->board[index + gs->width - 1] &&
            //     gs->board[index] == gs->board[index + 2 * gs->width - 2])
            // {
            //     if (gs->board[index] == 'X')
            //         player_1_3++;
            //     else
            //         player_2_3++;
            // }

            int x_count = (gs->board[index] == 'X') + (gs->board[index + gs->width - 1] == 'X') + (gs->board[index + 2 * gs->width - 2] == 'X');
            int o_count = (gs->board[index] == 'O') + (gs->board[index + gs->width - 1] == 'O') + (gs->board[index + 2 * gs->width - 2] == 'O');
            int empty_count = (gs->board[index] == '_') + (gs->board[index + gs->width - 1] == '_') + (gs->board[index + 2 * gs->width - 2] == '_');

            if (x_count == 3)
                player_1_3++;
            else if (o_count == 3)
                player_2_3++;
            else if (x_count == 2 && empty_count == 1)
                player_1_2++;
            else if (o_count == 2 && empty_count == 1)
                player_2_2++;
        }
    }

    gs->evaluation = 10 * (player_1_3 - player_2_3) + 3 * (player_1_2 - player_2_2);
}

int get_max(TreeNode* node) {
    if (!node || node->num_children == 0 || node->num_children < 0 || get_game_status(node->game_state) != IN_PROGRESS) {
        //printf("max: Leaf node evaluation: %d\n", node->game_state->evaluation); 
        return node->game_state->evaluation; // Leaf
    }

    int max_value = -100000;

    for (int i = 0; i <node->num_children; i++) {
        int value = get_min(node->children[i]);
        if (value > max_value) {
            max_value = value;
        }
    }

    return max_value;
}

int get_min(TreeNode* node) {

    if (!node || node->num_children == 0 || node->num_children < 0 || get_game_status(node->game_state) != IN_PROGRESS) {
        //printf("min: Leaf node evaluation: %d\n", node->game_state->evaluation); // Debugging output
        return node->game_state->evaluation; // Leaf
    }

    int min_value = 100000;

    for (int i = 0; i < node->num_children; i++) {
        int value = get_max(node->children[i]);
        if (value < min_value) {
            min_value = value;
        }
    }

    return min_value;
}

int best_move(TreeNode* root) {
    if (!root || root->num_children == 0 || root->num_children < 0) {
        return -1; 
    }
    eval_game_tree(root);

    GameState* gs = root->game_state;
    bool* moves = (bool*)malloc(gs->width * sizeof(bool));
    if (!moves) {
        return -1; 
    }

    int num_available_moves = available_moves(gs, moves);

    if (num_available_moves == 0) {
        free(moves);
        return -1; 
    }

    int best_index = -1;
    int best_value = -100000;

    print_available_moves(gs);
    printf("\n");
    for (int i = 0; i < gs->width; i++) {
        if (!moves[i] || !root->children[i]) {
            continue; 
        }
        printf("move: %d, eval: %d\n", i, root->children[i]->game_state->evaluation);
        int value = get_min(root->children[i]);
        
        if (value > best_value) {
            best_value = value;
            best_index = i;
        }
}

    free(moves);
    return best_index;
}


void eval_game_tree(TreeNode *root) {
    if (!root) {
        printf("[ERROR] Root is NULL\n");
        return;
    }

    if (root->num_children <= 0) {
        if (!root->game_state) {
            printf("[ERROR] Game state of leaf node is NULL\n");
            return;
        }
        eval_game_state(root->game_state);
        return;
    }

    for (int i = 0; i < root->num_children; i++) {
        if (root->children[i]) {
            eval_game_tree(root->children[i]);
        } else {
            printf("[ERROR] Child %d is NULL\n", i);
        }
    }

    int best_evaluation = root->children[0]->game_state->evaluation;
    for (int i = 1; i < root->num_children; i++) {
        if (root->children[i]) {
            int child_eval = root->children[i]->game_state->evaluation;
            if (child_eval > best_evaluation) {
                best_evaluation = child_eval;
            }
        }
    }

    root->game_state->evaluation = best_evaluation;
}





